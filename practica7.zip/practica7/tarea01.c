#include<stdio.h>
int main(){ 
    int opc,f,s,a,b;
    double k,l,j,h;
    printf("\n                   Programa que realiza cuatro operaciones");
    printf("\n                        selecciona la opcion deseada"); 
    printf("\n        1)operacion paso a apaso -3[-5+3(8*9)+5].  2)calculadora\n");
    printf("\nselecciona una opcion.");
    scanf("%d",&opc);
    switch(opc)
    {
        case 1: 
        printf("operacion paso a apaso de -3[-5+3(8*9)+5].");
        s=(8*9);
        printf("\nr=-3[-5+3(%i)+5]",s);
        s=3*s;
        printf("\nr=-3[-5+(%i)+5]",s);
        s=-5+s+5;
        printf("\nr=-3[(%i)]",s);
        s=-3*s;
        printf("\nr=%i",s);
        break;
        case 2:
        printf("                                CALCULADORA \n");
        printf("escribe un valor a\n");
        scanf("%i",&a);
        printf("\nescribe un valor b\n");
        scanf("%i",&b);
        printf("\nselecciona una operacion 1)a+b  2)a-b  3)a*b  4)a modular b");
        scanf("%d",&f);
        switch(f)
        {
            case 1:
            k=a+b;
            printf ("\na+b=%.3f",k);
            printf ("\n");
            break;
            case 2:
            k=a-b; 
            printf ("\na-b=%.3f",k);
            printf ("\n"); 
            break;
            case 3:
            k=a*b; 
            printf ("\na*b=%.3f",k); 
            printf ("\n");
            break;
            case 4:  
            k=a%b;
            printf ("\na mod b=%.3f",k);
            printf ("\n");
            break;
            default:
            printf ("\n operacion no valida.");
        }
        break;
        case 3:
        printf("\n");
        break;
        default:
        printf("opcion no valida");
        break;
        
        }
return 0;
}

